from flask import Flask, request, render_template_string
import bledev
import threading

app = Flask(__name__)
# Name your LED's however you like, also this Class setup is not optimal, so if you want to use it you should consider fixing it
PC = bledev.PC()
BED = bledev.BED()
ROOM = bledev.ROOM()
TV = bledev.TV()
SERVER = bledev.SERVER()
LAMP = bledev.LAMP()

def handle_led_async(device, state):
    def task():
        if state == "on":
            device.power_on()
        elif state == "off":
            device.power_off()
    threading.Thread(target=task).start()

def close_window_response(status):
    html = f"""
    <html>
        <body>
            <script>
                window.close();
            </script>
        </body>
    </html>
    """
    return render_template_string(html)

@app.route("/ledctrl/<device_name>", methods=["GET"])
def control_device(device_name):
    state = request.args.get("state")
    devices = {
        "pc": PC,
        "room": ROOM,
        "bed": BED,
        "tv": TV,
        "server": SERVER,
        "lamp": LAMP
    }
    device = devices.get(device_name.lower())
    if not device:
        return {"error": "Unknown device"}, 400
    if state not in ["on", "off"]:
        return {"error": "state=on oder state=off"}, 400

    # Fire-and-forget
    handle_led_async(device, state)
    
    # Sofortige Antwort, Fenster schließt sich
    return close_window_response(f"{device_name.upper()} LED {state}")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=6000)

