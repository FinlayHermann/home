from bluepy.btle import Peripheral
import colorsys
import subprocess
import serial
import time
import threading
import queue

def send(mac: str, uuid: str, cmd: str):
    attempts = 1
    while attempts <= 3:
        try:

            data = bytes.fromhex(cmd)
            try:
                peripheral = Peripheral(mac)

            except:
                peripheral = None

# This mac you need to figure out yourself, it is device specific
# And again, when I made this I didn't know how to use classes properly, so consider fixing it
            if mac == "XX:XX:XX:XX":
                mtu_size = 186
                peripheral.setMTU(mtu_size)

            characteristic = peripheral.getCharacteristics(uuid=uuid)[0]
            characteristic.write(data, withResponse=True)

            peripheral.disconnect()
            return 0

        except:
            try:
                result = subprocess.run(["sudo", "systemctl", "restart", "bluetooth"], check=True, capture_output=True, text=True)
            except:
                pass
            print(f"Attempt {attempts} failed. Trying Again...")
            attempts += 1

    return 1


class LAMP:
    def __init__(self):
        self.port = "/dev/ttyUSB0"
        self.baudrate = 9600
        self.name = "LAMP"

        self.ser = None
        self.send_queue = queue.Queue()
        self.running = False
        self.worker_thread = None

        self._start_serial()

    def _start_serial(self):
        self.ser = serial.Serial(self.port, self.baudrate, timeout=1)
        time.sleep(2)

        self.running = True
        self.worker_thread = threading.Thread(
            target=self._serial_worker,
            daemon=True
        )
        self.worker_thread.start()

    def _serial_worker(self):
        while self.running:
            try:
                addr, cmd = self.send_queue.get(timeout=0.1)
                message = f"{addr},{cmd}\n"
                self.ser.write(message.encode())

                response = self.ser.readline().decode().strip()
                #print("Arduino:", response)

            except queue.Empty:
                continue

    def ir_send(self, addr: int, cmd: int):
        self.send_queue.put((addr, cmd))

    def power_on(self):
        self.ir_send(addr=0xEF00, cmd=0x3)

    def power_off(self):
        self.ir_send(addr=0xEF00, cmd=0x2)

    def shutdown(self):
        self.running = False
        if self.worker_thread:
            self.worker_thread.join()

        if self.ser and self.ser.is_open:
            self.ser.close()


class PC:
    def __init__(self):
        self.mac = "BE:96:50:00:00:C0"
        self.uuid = "0000fff3-0000-1000-8000-00805f9b34fb"
        self.name = "PC"


    def power_on(self):
        send(mac=self.mac, uuid=self.uuid, cmd="7E00040100000000EF")

    def power_off(self):
        send(mac=self.mac, uuid=self.uuid, cmd="7E00040000000000EF")

    def color(self, r, g, b):
        color_string = ("%02x%02x%02x" % (r, g, b)).upper()
        cmd = f"7E000503{color_string}00EF"
        send(mac=self.mac, uuid=self.uuid, cmd=cmd)


class BED:
    def __init__(self):
        self.mac = "E4:98:BB:62:E8:62"
        self.uuid = "0000ff01-0000-1000-8000-00805f9b34fb"
        self.name = "BED"

    def power_on(self):
        send(mac=self.mac, uuid=self.uuid, cmd="00048000000D0E0B3B230000000000000032000090")

    def power_off(self):
        send(mac=self.mac, uuid=self.uuid, cmd="00048000000D0E0B3B240000000000000032000090")

    def color(self, r, g, b):
        r_norm = r / 255.0
        g_norm = g / 255.0
        b_norm = b / 255.0

        h, s, v = colorsys.rgb_to_hsv(r_norm, g_norm, b_norm)

        h = int(h * 180)
        s = int(s * 100)
        v = int(v * 100)

        color_string = ("%02x%02x%02x" % (h, s, v)).upper()
        cmd = f"00058000000d0e0b3ba1{color_string}0000000000000000"
        send(mac=self.mac, uuid=self.uuid, cmd=cmd)


class ROOM:
    def __init__(self):
        self.mac = "FF:FF:10:C0:EB:9B"
        self.uuid = "0000ee01-0000-1000-8000-00805f9b34fb"
        self.name = "ROOM"

    def power_on(self):
        send(mac=self.mac, uuid=self.uuid, cmd="6996060101")

    def power_off(self):
        send(mac=self.mac, uuid=self.uuid, cmd="6996020100")

    def color(self, r, g, b):
        color_string = ("%02x%02x%02x" % (r, g, b)).upper()
        cmd = f"69960502{color_string}00"
        send(mac=self.mac, uuid=self.uuid, cmd=cmd)
